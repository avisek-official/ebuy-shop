import { useState } from "react";
import { BsXCircleFill } from "react-icons/bs";
import { useDispatch } from "react-redux";

import { addAddress } from "../../redux/action";

import { AddAddress } from "./AddAddress";

const PlaceOrder = (props) => {
  document.title = "Place Order | eBuy Online Shopping";
  //   console.log(props.cartItems);
  //   console.log(props.cartTotal);
  //   console.log(props.loggedUserInfo);
  const dispatch = useDispatch();
  let addressArr = [];
  const [selectedAddress, setSelectedAddress] = useState([]);
  const [showAddAddress, setShowAddAddress] = useState(false);
  const [addSelected, setAddSelected] = useState(false);
  if (
    props.loggedUserInfo !== undefined &&
    Object.keys(props.loggedUserInfo.address).length > 0
  ) {
    for (const key in props.loggedUserInfo.address) {
      addressArr.push(props.loggedUserInfo.address[key]);
    }
  }
  const selectAddressHandler = (e) => {
    setSelectedAddress(e.target.value);
    setAddSelected(true);
  };

  const dispatchAddHandler = (address) => {
    dispatch(
      addAddress({
        userId: props.loggedUserInfo.id,
        address: address,
      })
    );
    setShowAddAddress(false);
  };

  const [alertToast, setAlertToast] = useState(false);

  return (
    <div className="w-full flex flex-col items-start justify-center">
      <div className="flex w-full justify-center">
        {/* Alert */}
        <div
          className={`${
            alertToast ? "fixed" : "hidden"
          } z-20 top-32  bg-red-400  text-red-900 rounded-md shadow-md shadow-gray-400 p-4`}
        >
          <span className="flex w-full justify-center items-center">
            <BsXCircleFill size={20} />
            &nbsp; Select A Delivery Address
          </span>
        </div>

        <div className="w-full md:w-1/2 flex flex-col p-4 justify-center items-center md:justify-start border-b-2 md:border-b-0 md:border-r-2 border-emerald-800">
          <span className="font-bold tracking-wider">
            Select Delivery Address
          </span>
          <span
            className={`${
              addSelected ? "" : "hidden"
            } flex w-full justify-between h-[30vh] items-center`}
          >
            <span className="w-[70%] flex">
              <b>{selectedAddress}</b>
            </span>
            <span className="w-[20%] flex justify-center p-3">
              <button
                className="bg-emerald-800 rounded-md shadow-md shadow-gray-400 px-4 py-1 text-white mx-2 active:scale-95 duration-150"
                onClick={() => {
                  setAddSelected(false);
                  setSelectedAddress([]);
                }}
              >
                Change
              </button>
            </span>
          </span>
          <span className={`${!addSelected ? "" : "hidden"}`}>
            {addressArr.length > 0 &&
              addressArr.map((address, index) => {
                return (
                  <span
                    key={index}
                    className="flex w-full justify-start items-center"
                  >
                    <input
                      className="w-[10%] h-5"
                      type="radio"
                      name="address"
                      value={`${address.fullname}, ${address.mobno}, ${address.address},\n${address.district} - ${address.pincode}`}
                      checked={
                        selectedAddress ===
                        `${address.fullname}, ${address.mobno}\n${address.address}, ${address.district} - ${address.pincode}`
                      }
                      onChange={selectAddressHandler}
                    />
                    <div
                      id="address-items"
                      className="flex justify-between items-center w-[80%] border-b border-gray-500 p-4 my-3"
                    >
                      <span className="flex flex-col w-[90%] justify-center items-start flex-wrap">
                        <span className="font-bold my-2">
                          {address.fullname} | {address.mobno}
                        </span>
                        <span>
                          {`${address.address}, ${address.district} - ${address.pincode}`}
                        </span>
                      </span>
                    </div>
                  </span>
                );
              })}

            <span className="w-full flex justify-center">
              <button
                className={`mt-5 px-3 py-2 rounded-md shadow-md shadow-gray-400 bg-emerald-800 text-white font-bold hover:bg-emerald-600 hover:scale-105 duration-150 active:scale-95 ${
                  showAddAddress && "hidden"
                }`}
                onClick={() => {
                  if (showAddAddress) {
                  } else {
                    setShowAddAddress(true);
                  }
                }}
              >
                + Add New Address
              </button>
              <AddAddress
                class={`${showAddAddress ? "flex" : "hidden"}`}
                setAddressData={dispatchAddHandler}
              />
            </span>
          </span>
        </div>
        <div className="w-full md:w-1/2 p-4 flex flex-col justify-center items-center md:justify-start">
          <span className="font-bold tracking-wider">
            Select Payment Method
          </span>
          <span className="w-[90%] flex justify-start items-center my-5">
            <input
              type="radio"
              name="paymentMethod"
              value="Cash on Delivery (COD)"
              defaultChecked
              className="h-5 mx-2"
            />
            Cash on Delivery (COD)
          </span>
        </div>
      </div>
      <span className="w-full flex justify-end">
        <button
          className="mt-5 px-3 py-2 rounded-md shadow-md shadow-gray-400 bg-emerald-800 text-white font-bold hover:bg-emerald-600 hover:scale-105 duration-150 active:scale-95"
          onClick={() => {
            if (selectedAddress.length > 0) {
              alert(selectedAddress);
            } else {
              setAlertToast(true);
              setTimeout(() => {
                setAlertToast(false);
              }, 3000);
            }
          }}
        >
          Place Order
        </button>
      </span>
    </div>
  );
};
export default PlaceOrder;
