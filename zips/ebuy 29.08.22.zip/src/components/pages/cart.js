import { BsCartX, BsEmojiSmile } from "react-icons/bs";
import {GiArchiveResearch} from "react-icons/gi"
import { Link } from "react-router-dom";

const Cart = (props) => {
  return (
    <div
      className={`w-[98%] md:w-4/5 min-h-[65vh] bg-white rounded-md shadow-md shadow-slate-400 flex flex-col items-center justify-start p-4 my-8`}
    >
      <div className="text-lg font-bold mb-2 flex items-center">
        <span className="mx-3">Things I am about to buy</span> <BsEmojiSmile />
      </div>
      <div className="h-[1px] bg-gray-500 w-full mb-3"></div>
      {/* Empty Cart */}
      <div className="w-full h-[55vh] flex flex-col justify-evenly items-center">
        <BsCartX size={90} />
        <div className="text-xl font-bold">Your cart is empty</div>
        <Link
          to={"/"}
          className="bg-emerald-800 text-white font-bold text-lg px-5 py-2 rounded-md shadow-md shadow-slate-300 hover:bg-emerald-600 hover:scale-105 duration-150 active:scale-95 flex justify-center items-center"
        >
          Explore Products
          <GiArchiveResearch className="mx-2" size={24}/>
        </Link>
      </div>
    </div>
  );
};

export default Cart;
