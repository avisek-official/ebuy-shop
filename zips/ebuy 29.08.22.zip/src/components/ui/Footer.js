const Footer = () => {
  return (
    <div
      id="footer-devename"
      className="w-full h-[30vh] bg-gradient-to-r from-emerald-900 to-emerald-500 mt-8 flex justify-center items-center"
    >
      <h1 className="text-white text-lg font-bold tracking-wider">
        Designed & Developed by: Avisek Kar
      </h1>
    </div>
  );
};
export default Footer;
