import { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router-dom/cjs/react-router-dom.min";

import { refreshUserAuth, getUserInfo } from "../../redux/action";

import { AiOutlineLoading } from "react-icons/ai";

const Orders = () => {
  document.title = "My Orders| eBuy Online Shopping";
  const [loginInfo, setLoginInfo] = useState(
    JSON.parse(localStorage.getItem("userAuth")) || null
  );
  const dispatch = useDispatch();
  const history = useHistory();
  const refreshedLoginData = useSelector((state) => state.LoginReducer);
  const userInfo = useSelector((state) => state.UserDataReducer);

  //Login Check --->
  useEffect(
    () => {
      if (loginInfo !== null) {
        dispatch(refreshUserAuth({ idToken: loginInfo.idToken }));
        dispatch(getUserInfo());
      }
    },
    // eslint-disable-next-line
    []
  );

  const loggedUser = [];
  if (loginInfo !== null) {
    if (refreshedLoginData === "error") {
      setLoginInfo(null);
      localStorage.removeItem("userAuth");
      history.push("/auth");
    } else {
      for (const key in userInfo) {
        if (userInfo[key].email === loginInfo.email) {
          let userDataVal = { ...userInfo[key], id: key };
          loggedUser.push(userDataVal);
        }
      }
    }
  }
  //<--- Login Check
  console.log(loggedUser[0]);
  return (
    <div className="w-[98%] md:w-4/5 min-h-[65vh] bg-white rounded-md shadow-md shadow-slate-400 flex flex-col items-center justify-start p-4 my-8">
      {userInfo === "loading" && (
        <span className="flex w-full my-24 justify-center item-center">
          <AiOutlineLoading
            size={90}
            className="text-emerald-800 animate-spin"
          />
        </span>
      )}
      {loggedUser[0] !== undefined && userInfo !== 'error' && (
        <>
          {userInfo !== "loading" &&
            loggedUser[0].orderHistory !== null &&
            Object.keys(loggedUser[0].orderHistory).length === 0 &&
            "You have not placed any order yet."}

          {userInfo !== "loading" &&
            loggedUser[0].orderHistory !== null &&
            Object.keys(loggedUser[0].orderHistory).length > 0 &&
            "Order List"}
        </>
      )}
    </div>
  );
};
export default Orders;
